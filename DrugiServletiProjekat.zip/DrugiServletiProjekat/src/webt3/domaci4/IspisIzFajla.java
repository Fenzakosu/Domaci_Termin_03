package webt3.domaci4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webt3.zad02.model.Osoba;

/**
 * Servlet implementation class IspisIzFajla
 */
@WebServlet("/IspisIzFajla")
public class IspisIzFajla extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		File fajl = (File)getServletContext().getAttribute("fajl");
		ArrayList<Osoba> osobe= new ArrayList<Osoba>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(fajl));
			br.mark(1);
			if(br.read()!='\ufeff') {
				br.reset();
			}
				
			String tekst;
			while((tekst = br.readLine()) != null) {
				String[] osoba = tekst.split(",");
				osobe.add(new Osoba(osoba[0], osoba[1]));
				
			}
			br.close();
		}catch(Exception e) {
			
		}
		response.setContentType("text/html; charset=UTF-8");
        PrintWriter pw = response.getWriter();
        pw.println("<html>");
        pw.println("<head>");
        pw.println("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        pw.println("</head>");
        pw.println("<body>");
        pw.println("	<h1>Ispis Liste osoba iz Fajla</h1>");
        pw.println("	<ol>");
        for (Osoba o : osobe) {
            pw.println(
            	   "		<li>" + o.getIme()+" "+o.getPrezime()+ "</li>");
        }
        pw.println("	</ol>");
        pw.println("	<ul>");
        pw.println("			<li><a href=\"formaGet.html\">Dodaj Osobu</a></li>");
        pw.println("			<li><a href=\"pocetna.html\">povratak</a></li>");
        pw.println("	</ul>");
        pw.println("</body>");
        pw.println("</html>");
        pw.flush();
        pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
