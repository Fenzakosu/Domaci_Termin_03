package webt3.domaci4;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webt3.zad02.model.Osoba;

/**
 * Servlet implementation class UpisUFajl
 */
@WebServlet("/UpisUFajl")
public class UpisUFajl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpisUFajl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		
	}

	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<Osoba> sveOsobe = (ArrayList<Osoba>)getServletContext().getAttribute("listaOsoba");
		
		String s = System.getProperty("file.separator");
		String path = s + "data" + s + "podaci.csv";
		String rPath = getServletContext().getRealPath(path);
		
		File fajl = new File(rPath);
		
		try(PrintWriter pw = new PrintWriter(new FileWriter(fajl))) {
			
			for(Osoba os : sveOsobe) {
				
				pw.println(os.getIme()+","+os.getPrezime());
			}
			getServletContext().setAttribute("fajl", (Object)fajl);
			
		}catch(Exception e) {
			resp.setContentType("text/html; charset=UTF-8");
	        PrintWriter pw = resp.getWriter();
	        pw.println("<html>");
	        pw.println("<head>");
	        pw.println("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
	        pw.println("</head>");
	        pw.println("<body>");
	        pw.println("	<h1>Exception</h1>");
	        pw.println("	<p>Usro motku</p>");
	        pw.println("	<ul>");
	        pw.println("			<li><a href=\"formaGet.html\">Dodaj Osobu</a></li>");
	        pw.println("			<li><a href=\"pocetna.html\">povratak</a></li>");
	        pw.println("			<li><a href=\"IspisIzFajla\">[Ovde] </a><br/>mozete pogledati listu koja je zapisana u fajl</li>");
	        pw.println("	</ul>");
	        pw.println("</body>");
	        pw.println("</html>");
	        pw.flush();
	        pw.close();
		}
		resp.setContentType("text/html; charset=UTF-8");
        PrintWriter pw = resp.getWriter();
        pw.println("<html>");
        pw.println("<head>");
        pw.println("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        pw.println("</head>");
        pw.println("<body>");
        pw.println("	<h1>Valjda uspesno zapisano u fajl</h1>");
        pw.println("	<p><a href=\"IspisIzFajla\">[Ovde] </a><br/>tu proveri da li je uspelo</p>");
        pw.println("	<ul>");
        pw.println("			<li><a href=\"formaGet.html\">Dodaj Osobu</a></li>");
        pw.println("			<li><a href=\"pocetna.html\">povratak</a></li>");
        pw.println("			<li><a href=\"IspisIzFajla\">[Ovde] </a><br/>mozete pogledati listu koja je zapisana u fajl</li>");
        pw.println("	</ul>");
        pw.println("</body>");
        pw.println("</html>");
        pw.flush();
        pw.close();
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
	

}
