package webt3.zad02;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import webt3.domaci4.UpisUFajl;
import webt3.zad02.model.Osoba;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.ServletException;
import javax.servlet.ServletConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;

@WebServlet({ "/PrihvatanjePodataka" })
public class PrihvatanjePodataka extends HttpServlet {
    private static final long serialVersionUID = 1L;
    ArrayList<Osoba> listaOsoba;
    
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        listaOsoba  = new ArrayList<Osoba>();
        getServletContext().setAttribute("listaOsoba", listaOsoba );
        
//        String putanja = getServletContext().getRealPath("/osoba.csv");
//    	File fajl = new File(putanja);
//    	try {
//			fajl.createNewFile();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
        String sP = System.getProperty("file.separator");
        File fajl = new File("."+sP+"osobe.csv");
    			
    	getServletContext().setAttribute("fajl", fajl);
    	
		
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	//kreiranje objekra osoba u memoriji
    	Osoba osoba = new Osoba(request.getParameter("ime"), request.getParameter("prezime"));
    	//dodavanje u listu
    	
    	listaOsoba.add(osoba);
    	
    	
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter pw = response.getWriter();
        pw.println("<html>");
        pw.println("<body>");
        pw.println("	<h1>Prihvatanje podataka</h1>");
       // pw.println("	Klijent koji je pozvao ovaj servlet je: " + request.getHeader("User-Agent"));
        pw.println("	<p>Uneli ste novu osobu: "+osoba.getIme()+" "+osoba.getPrezime()+"</p>");
        pw.println("	<a href=\"formaGet.html\">Dodaj Osobu</a>");
        pw.println("	<p><a href=\"IspisSvihOsoba\">[Ovde] </a><br/>mozete pogledati listu svih unetih osoba</p>");
        pw.println("	<p><a href=\"IspisParnihOsoba\">[Ovde] </a><br/>mozete pogledati listu parnih osoba</p>");
        pw.println("	<p><a href=\"IspisNeparnihOsoba\">[Ovde] </a><br/>mozete pogledati listu neparnih osoba</p>");
        pw.println("	<p><a href=\"UpisUFajl\">[Ovde] </a><br/>kliknes da se osobe upisu u fajl</p>");
        pw.println("	<p><a href=\"IspisIzFajla\">[Ovde] </a><br/>mozete pogledati listu koja je zapisana u fajl</p>");
        
        pw.println("	<a href=\"pocetna.html\">povratak</a>");
        pw.println("</body>");
        pw.println("</html>");
        pw.flush();
        pw.close();
    }
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}