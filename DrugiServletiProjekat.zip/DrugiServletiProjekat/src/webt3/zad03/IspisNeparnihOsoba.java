package webt3.zad03;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webt3.zad02.model.Osoba;

/**
 * Servlet implementation class IspisNeparnihOsoba
 */
@WebServlet("/IspisNeparnihOsoba")
public class IspisNeparnihOsoba extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IspisNeparnihOsoba() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ArrayList<Osoba> sveOsobe = (ArrayList<Osoba>)getServletContext().getAttribute("listaOsoba");
		response.setContentType("text/html; charset=UTF-8");
        PrintWriter pw = response.getWriter();
        pw.println("<html>");
        pw.println("<head>");
        pw.println("	<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">");
        pw.println("</head>");
        pw.println("<body>");
        pw.println("	<h1>Prikaz Osoba iz liste sa neparnim indexom</h1>");
        pw.println("	<ul>");
        for (int i=0; i<sveOsobe.size();i=i+2) {
        	Osoba o=sveOsobe.get(i);
            pw.println(
            	   "		<li>["+i+"]" + o.getIme()+" "+o.getPrezime()+ "</li>");
        }
        pw.println("	</ul>");
        pw.println("	<ul>");
        pw.println("			<li><a href=\"formaGet.html\">Dodaj Osobu</a></li>");
        pw.println("			<li><a href=\"pocetna.html\">povratak</a></li>");
        pw.println("	</ul>");
        pw.println("</body>");
        pw.println("</html>");
        pw.flush();
        pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
